<?php
function home() {
    $_GET["action"]="home";
    require "view/home.php";
}

function login() {
    $_GET["action"]="login";
    require "view/login.php";

}


