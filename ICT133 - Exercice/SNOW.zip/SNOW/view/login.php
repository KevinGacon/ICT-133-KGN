<?php
ob_start();
?>
    <title>Rent A Snow - Login</title>
    <br><br><h1 style="color: #db6400">Login</h1>

    <form action="suite.php" method="post">

        <div style="margin-right: 0">
            <label for="uname"><b>Username</b></label>
            <input type="text" placeholder="Enter Username" name="uname" required>

            <label for="psw"><b>Password</b></label>
            <input type="password" placeholder="Enter Password" name="psw" required>
            <hr/>
            <button type="submit" >Login</button> <button>Reset</button>
        </div>

    </form>

<?php
$content = ob_get_clean();
require "gabarit.php";