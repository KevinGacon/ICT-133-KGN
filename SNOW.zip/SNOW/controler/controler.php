<?php
session_start();


require "model/model.php";

function home()
{
    $_GET["action"]="home";
    require "view/home.php";
}

function login($post)
{
    $_GET["action"] = "login";

    if (checkLogin($post))
    {
        require "view/home.php";
    }
    else {
        require "view/login.php";
    }
}

function logout()
{
    $_GET["action"]="home";
    require "view/logout.php";
}



