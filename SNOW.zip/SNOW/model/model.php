<?php
function checkLogin($data)
{
    if(@$data['psw']== "1234") {
        $_SESSION['Username'] = $_POST['uname'];
        $_SESSION['Password'] = $_POST['psw'];
        return true;
    }else{
        return false;
    }
}
